from django.apps import AppConfig


class InvestorappConfig(AppConfig):
    name = 'investorApp'
