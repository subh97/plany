from django.apps import AppConfig


class ContactusappConfig(AppConfig):
    name = 'contactUsApp'
