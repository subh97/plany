from django import forms
from .models import *

#code need to be  add by Shubham starts

class investorPersonalDetailsForm(forms.ModelForm):
	class Meta:
		model = investorPersonalDetails
		exclude = ('profileOwner','author','publish','created','updated','status')

class investmentDetailsForm(forms.ModelForm):
	class Meta:
		model = investmentDetails
		exclude = ('profileOwner','author','publish','created','updated','status')

class investorBankDetailsForm(forms.ModelForm):
	class Meta:
		model=investorBankDetails
		exclude=('profileOwnerFK','author','publish','created','updated','status')

class investorDMATDetailsForm(forms.ModelForm):
	class Meta:
		model=investorDMATDetails
		exclude=('profileOwner','author','publish','created','updated','status')


class stockBrokerDetailsForm(forms.ModelForm):
	class Meta:
		model=stockBrokerDetails
		exclude=('author','publish','created','updated','status')
		
class lookingToInvestDetailsForm(forms.ModelForm):
	class Meta:
		model=investmentINDetails
		exclude=('author','publish','created','updated','status')

#code need to be add by shubham ends


